using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Agencia.Models;

namespace Agencia.Controllers
{
    public class ClienteTelefoneController : Controller
    {
        private readonly AgenciaDbContext _context;

        public ClienteTelefoneController(AgenciaDbContext context)
        {
            _context = context;
        }

        // GET: ClienteTelefone
        public async Task<IActionResult> Index()
        {
            var agenciaDbContext = _context.ClienteTelefones.Include(c => c.IdClienteNavigation).Include(c => c.IdTelefoneNavigation);
            return View(await agenciaDbContext.ToListAsync());
        }

        // GET: ClienteTelefone/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clienteTelefone = await _context.ClienteTelefones
                .Include(c => c.IdClienteNavigation)
                .Include(c => c.IdTelefoneNavigation)
                .FirstOrDefaultAsync(m => m.IdCliente == id);
            if (clienteTelefone == null)
            {
                return NotFound();
            }

            return View(clienteTelefone);
        }

        // GET: ClienteTelefone/Create
        public IActionResult Create()
        {
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf");
            ViewData["IdTelefone"] = new SelectList(_context.Telefones, "IdTelefone", "NroTelefone");
            return View();
        }

        // POST: ClienteTelefone/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdCliente,IdTelefone")] ClienteTelefone clienteTelefone)
        {
            if (ModelState.IsValid)
            {
                _context.Add(clienteTelefone);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf", clienteTelefone.IdCliente);
            ViewData["IdTelefone"] = new SelectList(_context.Telefones, "IdTelefone", "NroTelefone", clienteTelefone.IdTelefone);
            return View(clienteTelefone);
        }

        // GET: ClienteTelefone/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clienteTelefone = await _context.ClienteTelefones.FindAsync(id);
            if (clienteTelefone == null)
            {
                return NotFound();
            }
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf", clienteTelefone.IdCliente);
            ViewData["IdTelefone"] = new SelectList(_context.Telefones, "IdTelefone", "NroTelefone", clienteTelefone.IdTelefone);
            return View(clienteTelefone);
        }

        // POST: ClienteTelefone/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdCliente,IdTelefone")] ClienteTelefone clienteTelefone)
        {
            if (id != clienteTelefone.IdCliente)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(clienteTelefone);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClienteTelefoneExists(clienteTelefone.IdCliente))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf", clienteTelefone.IdCliente);
            ViewData["IdTelefone"] = new SelectList(_context.Telefones, "IdTelefone", "NroTelefone", clienteTelefone.IdTelefone);
            return View(clienteTelefone);
        }

        // GET: ClienteTelefone/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clienteTelefone = await _context.ClienteTelefones
                .Include(c => c.IdClienteNavigation)
                .Include(c => c.IdTelefoneNavigation)
                .FirstOrDefaultAsync(m => m.IdCliente == id);
            if (clienteTelefone == null)
            {
                return NotFound();
            }

            return View(clienteTelefone);
        }

        // POST: ClienteTelefone/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var clienteTelefone = await _context.ClienteTelefones.FindAsync(id);
            _context.ClienteTelefones.Remove(clienteTelefone);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClienteTelefoneExists(int id)
        {
            return _context.ClienteTelefones.Any(e => e.IdCliente == id);
        }
    }
}
