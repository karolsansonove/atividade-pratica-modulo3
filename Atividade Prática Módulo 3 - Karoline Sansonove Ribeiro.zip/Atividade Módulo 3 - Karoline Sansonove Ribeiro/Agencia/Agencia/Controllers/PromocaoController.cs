using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Agencia.Models;

namespace Agencia.Controllers
{
    public class PromocaoController : Controller
    {
        private readonly AgenciaDbContext _context;

        public PromocaoController(AgenciaDbContext context)
        {
            _context = context;
        }

        // GET: Promocao
        public async Task<IActionResult> Index()
        {
            var agenciaDbContext = _context.Promocaos.Include(p => p.IdDestinoNavigation);
            return View(await agenciaDbContext.ToListAsync());
        }

        // GET: Promocao/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var promocao = await _context.Promocaos
                .Include(p => p.IdDestinoNavigation)
                .FirstOrDefaultAsync(m => m.IdPromocao == id);
            if (promocao == null)
            {
                return NotFound();
            }

            return View(promocao);
        }

        // GET: Promocao/Create
        public IActionResult Create()
        {
            ViewData["IdDestino"] = new SelectList(_context.Destinos, "IdDestino", "LocalDestino");
            return View();
        }

        // POST: Promocao/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdPromocao,Descricao,PercDesconto,DataVencimento,IdDestino")] Promocao promocao)
        {
            if (ModelState.IsValid)
            {
                _context.Add(promocao);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdDestino"] = new SelectList(_context.Destinos, "IdDestino", "LocalDestino", promocao.IdDestino);
            return View(promocao);
        }

        // GET: Promocao/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var promocao = await _context.Promocaos.FindAsync(id);
            if (promocao == null)
            {
                return NotFound();
            }
            ViewData["IdDestino"] = new SelectList(_context.Destinos, "IdDestino", "LocalDestino", promocao.IdDestino);
            return View(promocao);
        }

        // POST: Promocao/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdPromocao,Descricao,PercDesconto,DataVencimento,IdDestino")] Promocao promocao)
        {
            if (id != promocao.IdPromocao)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(promocao);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PromocaoExists(promocao.IdPromocao))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdDestino"] = new SelectList(_context.Destinos, "IdDestino", "LocalDestino", promocao.IdDestino);
            return View(promocao);
        }

        // GET: Promocao/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var promocao = await _context.Promocaos
                .Include(p => p.IdDestinoNavigation)
                .FirstOrDefaultAsync(m => m.IdPromocao == id);
            if (promocao == null)
            {
                return NotFound();
            }

            return View(promocao);
        }

        // POST: Promocao/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var promocao = await _context.Promocaos.FindAsync(id);
            _context.Promocaos.Remove(promocao);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PromocaoExists(int id)
        {
            return _context.Promocaos.Any(e => e.IdPromocao == id);
        }
    }
}
