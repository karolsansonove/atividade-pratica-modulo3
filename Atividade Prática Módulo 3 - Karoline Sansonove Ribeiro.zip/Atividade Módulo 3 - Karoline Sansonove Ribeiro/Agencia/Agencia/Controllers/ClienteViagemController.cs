using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Agencia.Models;

namespace Agencia.Controllers
{
    public class ClienteViagemController : Controller
    {
        private readonly AgenciaDbContext _context;

        public ClienteViagemController(AgenciaDbContext context)
        {
            _context = context;
        }

        // GET: ClienteViagem
        public async Task<IActionResult> Index()
        {
            var agenciaDbContext = _context.ClienteViagems.Include(c => c.IdClienteNavigation).Include(c => c.IdViagemNavigation);
            return View(await agenciaDbContext.ToListAsync());
        }

        // GET: ClienteViagem/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clienteViagem = await _context.ClienteViagems
                .Include(c => c.IdClienteNavigation)
                .Include(c => c.IdViagemNavigation)
                .FirstOrDefaultAsync(m => m.IdCliVia == id);
            if (clienteViagem == null)
            {
                return NotFound();
            }

            return View(clienteViagem);
        }

        // GET: ClienteViagem/Create
        public IActionResult Create()
        {
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf");
            ViewData["IdViagem"] = new SelectList(_context.Viagems, "IdViagem", "IdViagem");
            return View();
        }

        // POST: ClienteViagem/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdCliVia,IdViagem,IdCliente")] ClienteViagem clienteViagem)
        {
            if (ModelState.IsValid)
            {
                _context.Add(clienteViagem);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf", clienteViagem.IdCliente);
            ViewData["IdViagem"] = new SelectList(_context.Viagems, "IdViagem", "IdViagem", clienteViagem.IdViagem);
            return View(clienteViagem);
        }

        // GET: ClienteViagem/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clienteViagem = await _context.ClienteViagems.FindAsync(id);
            if (clienteViagem == null)
            {
                return NotFound();
            }
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf", clienteViagem.IdCliente);
            ViewData["IdViagem"] = new SelectList(_context.Viagems, "IdViagem", "IdViagem", clienteViagem.IdViagem);
            return View(clienteViagem);
        }

        // POST: ClienteViagem/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdCliVia,IdViagem,IdCliente")] ClienteViagem clienteViagem)
        {
            if (id != clienteViagem.IdCliVia)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(clienteViagem);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClienteViagemExists(clienteViagem.IdCliVia))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCliente"] = new SelectList(_context.Clientes, "IdCliente", "Cpf", clienteViagem.IdCliente);
            ViewData["IdViagem"] = new SelectList(_context.Viagems, "IdViagem", "IdViagem", clienteViagem.IdViagem);
            return View(clienteViagem);
        }

        // GET: ClienteViagem/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clienteViagem = await _context.ClienteViagems
                .Include(c => c.IdClienteNavigation)
                .Include(c => c.IdViagemNavigation)
                .FirstOrDefaultAsync(m => m.IdCliVia == id);
            if (clienteViagem == null)
            {
                return NotFound();
            }

            return View(clienteViagem);
        }

        // POST: ClienteViagem/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var clienteViagem = await _context.ClienteViagems.FindAsync(id);
            _context.ClienteViagems.Remove(clienteViagem);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClienteViagemExists(int id)
        {
            return _context.ClienteViagems.Any(e => e.IdCliVia == id);
        }
    }
}
