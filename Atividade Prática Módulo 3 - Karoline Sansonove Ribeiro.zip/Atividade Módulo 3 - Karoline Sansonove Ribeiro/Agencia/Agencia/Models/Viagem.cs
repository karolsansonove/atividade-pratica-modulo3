﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class Viagem
    {
        public Viagem()
        {
            ClienteViagems = new HashSet<ClienteViagem>();
        }

        public int IdViagem { get; set; }
        public short QtdPessoas { get; set; }
        public DateTime DataViagem { get; set; }
        public int IdDestino { get; set; }

        public virtual Destino IdDestinoNavigation { get; set; }
        public virtual ICollection<ClienteViagem> ClienteViagems { get; set; }
    }
}
