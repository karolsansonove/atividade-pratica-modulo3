﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class ClienteTelefone
    {
        public int IdCliente { get; set; }
        public int IdTelefone { get; set; }

        public virtual Cliente IdClienteNavigation { get; set; }
        public virtual Telefone IdTelefoneNavigation { get; set; }
    }
}
