﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class Telefone
    {
        public Telefone()
        {
            ClienteTelefones = new HashSet<ClienteTelefone>();
        }

        public int IdTelefone { get; set; }
        public string NroTelefone { get; set; }

        public virtual ICollection<ClienteTelefone> ClienteTelefones { get; set; }
    }
}
