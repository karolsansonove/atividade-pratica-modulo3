﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class ClienteViagem
    {
        public int IdCliVia { get; set; }
        public int IdViagem { get; set; }
        public int IdCliente { get; set; }

        public virtual Cliente IdClienteNavigation { get; set; }
        public virtual Viagem IdViagemNavigation { get; set; }
    }
}
