﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Agencia.Models
{
    public partial class AgenciaDbContext : DbContext
    {
        public AgenciaDbContext()
        {
        }

        public AgenciaDbContext(DbContextOptions<AgenciaDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cliente> Clientes { get; set; }
        public virtual DbSet<ClienteTelefone> ClienteTelefones { get; set; }
        public virtual DbSet<ClienteViagem> ClienteViagems { get; set; }
        public virtual DbSet<Destino> Destinos { get; set; }
        public virtual DbSet<Promocao> Promocaos { get; set; }
        public virtual DbSet<Telefone> Telefones { get; set; }
        public virtual DbSet<Viagem> Viagems { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=KAROLINE;Initial Catalog=Agencia_Viagens;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Cliente>(entity =>
            {
                entity.HasKey(e => e.IdCliente)
                    .HasName("PK__Cliente__D5946642F6B35D6C");

                entity.ToTable("Cliente");

                entity.Property(e => e.Cpf)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.DataNasc).HasColumnType("date");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.Passaporte)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<ClienteTelefone>(entity =>
            {
                entity.HasKey(e => new { e.IdCliente, e.IdTelefone })
                    .HasName("PK__Cliente___5C2CCA38D8746370");

                entity.ToTable("Cliente_Telefone");

                entity.HasOne(d => d.IdClienteNavigation)
                    .WithMany(p => p.ClienteTelefones)
                    .HasForeignKey(d => d.IdCliente)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_CliTel_Cliente");

                entity.HasOne(d => d.IdTelefoneNavigation)
                    .WithMany(p => p.ClienteTelefones)
                    .HasForeignKey(d => d.IdTelefone)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_CliTel_Telefone");
            });

            modelBuilder.Entity<ClienteViagem>(entity =>
            {
                entity.HasKey(e => e.IdCliVia)
                    .HasName("PK__Cliente___C2C2C4642E26B304");

                entity.ToTable("Cliente_Viagem");

                entity.HasOne(d => d.IdClienteNavigation)
                    .WithMany(p => p.ClienteViagems)
                    .HasForeignKey(d => d.IdCliente)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_CliVia_Cliente");

                entity.HasOne(d => d.IdViagemNavigation)
                    .WithMany(p => p.ClienteViagems)
                    .HasForeignKey(d => d.IdViagem)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_CliVia_Viagem");
            });

            modelBuilder.Entity<Destino>(entity =>
            {
                entity.HasKey(e => e.IdDestino)
                    .HasName("PK__Destino__55FFB3D5C1D066ED");

                entity.ToTable("Destino");

                entity.Property(e => e.LocalDestino)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Preco).HasColumnType("decimal(10, 2)");
            });

            modelBuilder.Entity<Promocao>(entity =>
            {
                entity.HasKey(e => e.IdPromocao)
                    .HasName("PK__Promocao__3E6A26983D4DE195");

                entity.ToTable("Promocao");

                entity.Property(e => e.DataVencimento).HasColumnType("date");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PercDesconto).HasColumnType("decimal(4, 2)");

                entity.HasOne(d => d.IdDestinoNavigation)
                    .WithMany(p => p.Promocaos)
                    .HasForeignKey(d => d.IdDestino)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Promocao_Destino");
            });

            modelBuilder.Entity<Telefone>(entity =>
            {
                entity.HasKey(e => e.IdTelefone)
                    .HasName("PK__Telefone__9B8AC7A976947B48");

                entity.ToTable("Telefone");

                entity.Property(e => e.NroTelefone)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Viagem>(entity =>
            {
                entity.HasKey(e => e.IdViagem)
                    .HasName("PK__Viagem__34DBC88931331FD4");

                entity.ToTable("Viagem");

                entity.Property(e => e.DataViagem).HasColumnType("date");

                entity.HasOne(d => d.IdDestinoNavigation)
                    .WithMany(p => p.Viagems)
                    .HasForeignKey(d => d.IdDestino)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Viagem_Destino");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
