﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class Destino
    {
        public Destino()
        {
            Promocaos = new HashSet<Promocao>();
            Viagems = new HashSet<Viagem>();
        }

        public int IdDestino { get; set; }
        public decimal Preco { get; set; }
        public string LocalDestino { get; set; }

        public virtual ICollection<Promocao> Promocaos { get; set; }
        public virtual ICollection<Viagem> Viagems { get; set; }
    }
}
