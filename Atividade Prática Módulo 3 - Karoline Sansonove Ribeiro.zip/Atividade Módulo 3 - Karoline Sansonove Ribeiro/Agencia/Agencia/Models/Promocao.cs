﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class Promocao
    {
        public int IdPromocao { get; set; }
        public string Descricao { get; set; }
        public decimal PercDesconto { get; set; }
        public DateTime DataVencimento { get; set; }
        public int IdDestino { get; set; }

        public virtual Destino IdDestinoNavigation { get; set; }
    }
}
