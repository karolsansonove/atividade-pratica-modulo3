﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Agencia.Models
{
    public partial class Cliente
    {
        public Cliente()
        {
            ClienteTelefones = new HashSet<ClienteTelefone>();
            ClienteViagems = new HashSet<ClienteViagem>();
        }

        public int IdCliente { get; set; }
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Passaporte { get; set; }
        public DateTime DataNasc { get; set; }

        public virtual ICollection<ClienteTelefone> ClienteTelefones { get; set; }
        public virtual ICollection<ClienteViagem> ClienteViagems { get; set; }
    }
}
