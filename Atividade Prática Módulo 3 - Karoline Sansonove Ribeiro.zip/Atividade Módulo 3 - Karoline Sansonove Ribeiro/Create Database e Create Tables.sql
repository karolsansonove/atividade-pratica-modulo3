create database Agencia_Viagens;

use Agencia_Viagens;

CREATE TABLE Destino(
	IdDestino INT PRIMARY KEY IDENTITY,
	Preco DECIMAL(10,2) NOT NULL,
	LocalDestino VARCHAR(80) NOT NULL
);

CREATE TABLE Cliente(
	IdCliente INT PRIMARY KEY IDENTITY,
	Nome VARCHAR(45) NOT NULL,
	Cpf CHAR(11) NOT NULL,
	Passaporte CHAR(8) NOT NULL,
	DataNasc DATE NOT NULL
);

CREATE TABLE Viagem(
	IdViagem INT PRIMARY KEY IDENTITY,
	QtdPessoas SMALLINT NOT NULL,
	DataViagem DATE NOT NULL, -- FORMATO 'AAAA-MM-DD'
	IdDestino INT NOT NULL, -- ADICIONAR FK
	CONSTRAINT fk_Viagem_Destino FOREIGN KEY(IdDestino) REFERENCES Destino(IdDestino)
);

CREATE TABLE Cliente_Viagem(
	IdCliVia INT PRIMARY KEY IDENTITY,
	IdViagem INT NOT NULL,
	IdCliente INT NOT NULL
	CONSTRAINT fk_CliVia_Viagem FOREIGN KEY(IdViagem) REFERENCES Viagem(IdViagem),
	CONSTRAINT fk_CliVia_Cliente FOREIGN KEY(IdCliente) REFERENCES Cliente(IdCliente)
);

CREATE TABLE Telefone(
	IdTelefone INT PRIMARY KEY IDENTITY,
	NumeroTelefone VARCHAR(11) NOT NULL
);

CREATE TABLE Cliente_Telefone(
	IdCliente INT NOT NULL,
	IdTelefone INT NOT NULL,
	PRIMARY KEY(IdCliente, IdTelefone),
	CONSTRAINT fk_CliTel_Cliente FOREIGN KEY(IdCliente) REFERENCES Cliente(IdCliente),
	CONSTRAINT fk_CliTel_Telefone FOREIGN KEY(IdTelefone) REFERENCES Telefone(IdTelefone)
);

CREATE TABLE Promocao(
	IdPromocao INT PRIMARY KEY IDENTITY,
	Descricao VARCHAR(100) NOT NULL,
	PercDesconto DECIMAL(4,2) NOT NULL,
	DataVencimento DATE NOT NULL,
	IdDestino INT NOT NULL,
	CONSTRAINT fk_Promocao_Destino FOREIGN KEY(IdDestino) REFERENCES Destino(IdDestino)
);